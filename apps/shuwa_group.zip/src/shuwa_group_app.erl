%%%-------------------------------------------------------------------
%%--------------------------------------------------------------------
%% Copyright (c) 2016-2017 shuwa .
%%
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/lager:/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.
%%--------------------------------------------------------------------

%% @doc
%%
%% shuwa_group_app:
%%
%%
%%
%% @end
-module(shuwa_group_app).

-emqx_plugin(?MODULE).

-behaviour(application).


-include("shuwa_group.hrl").

%% Application callbacks
-export([start/2, stop/1]).


%% ===================================================================
%% Application callbacks
%% ===================================================================

start(_StartType, _StartArgs) ->
    shuwa_metrics:start(shuwa_group),
    shuwa_data:init(?SHUWA_GROUP),
    shuwa_data:init(?SHUWA_GROUP_ROUTE),
    shuwa_data:init(?SHUWA_GROUP_TASK),
    shuwa_data:init(?SHUWA_GROUP_METER),
    shuwa_data:init(?SHUWA_GROUP_WORK),
    {ok, Sup} = shuwa_group_sup:start_link(),
    {ok, Sup}.


stop(_State) ->
    ok.
