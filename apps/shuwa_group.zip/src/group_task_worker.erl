%%%-------------------------------------------------------------------
%%% @author johnliu
%%% @copyright (C) 2019, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 09. 九月 2019 11:30
%%%-------------------------------------------------------------------
-module(group_task_worker).
-author("johnliu").
-include("shuwa_group.hrl").

-behaviour(gen_server).

%% API
-export([start_link/1]).

%% gen_server callbacks
-export([init/1, handle_call/3, handle_cast/2,
    handle_info/2, terminate/2, code_change/3]).

-record(task, {tid, mid, di, mod, func,
               usedata = none, delay = 2, retry = none, que = none, times = 3600, ts = 0}).
%%%===================================================================
%%% API
%%%===================================================================
start_link(#{<<"tid">> := Tid, <<"di">> := Di, <<"mid">> := Mid} = State) ->
    case shuwa_data:lookup(?SHUWA_GROUP_TASK, {Mid, Tid, Di}) of
        {ok, Pid} when is_pid(Pid) ->
            is_process_alive(Pid) andalso gen_server:call(Pid, stop, 5000);
        _Reason ->
            ok
    end,
    gen_server:start_link(?MODULE, [State], []).
%%%===================================================================
%%% gen_server callbacks
%%%===================================================================
init([#{<<"tid">> := Tid, <<"di">> := Di, <<"mid">> := Mid,<<"mod">> := Mod, <<"fun">> := Fun,
    <<"delay">> := Delay, <<"retry">> := Retry, <<"begin">> := Begin, <<"times">> := Times,
    <<"que">> := Que, <<"quelen">> := QueLen, <<"usedata">> := Usedata}]) ->
    BinMid = shuwa_utils:to_binary(Mid),
    shuwa_data:insert(?SHUWA_GROUP_TASK, {Mid, Tid, Di}, self()),
    Consumer = <<"task/",Di/binary, "/",BinMid/binary>>,
    shuwa_data:set_consumer(Consumer, QueLen),
    TimeToLive = <<"task/times/",BinMid/binary>>,
    shuwa_data:set_consumer(TimeToLive, Times),
    erlang:send_after(Delay * Mid + Begin, self(), delay),
    {ok, #task{tid = Tid, mid = Mid, di = Di, mod = Mod, func = Fun,
        delay = Delay, retry = Retry, que = Que, usedata  = Usedata, times = Times}};

init(A) ->
    lager:info("A ~p ",[A]).

handle_call(stop, _From, State) ->
    {stop, normal, ok, State};

handle_call(_Request, _From, State) ->
    {reply, noreply, State}.

handle_cast(_Msg, State) ->
    {noreply, State}.

handle_info({'EXIT', _From, Reason}, State) ->
    {stop, Reason, State};

handle_info(stop, State) ->
    {stop, normal, State};

%延迟启动
handle_info(delay, State) ->
    erlang:send_after(100, self(), retry),
    {noreply, State};

% 定时执行
handle_info(retry, #task{di = Di, mid = Mid, mod = Mod, func = Fun,
    retry = Retry, que = Que, usedata = Usedata} = State) ->
    BinMid = shuwa_utils:to_binary(Mid),
    Consumer = <<"task/",Di/binary, "/",BinMid/binary>>,
    Offset = shuwa_data:get_consumer(Consumer,1),
    TimeConsumer = <<"task/times/",BinMid/binary>>,
    TimeToLive = shuwa_data:get_consumer(TimeConsumer, 1),
    Mod:Fun(#{<<"que">> => Que, <<"offset">> => Offset, <<"usedata">> => {Mid, Usedata, TimeToLive}}),
    erlang:send_after(Retry, self(), retry),
    {noreply, State};

handle_info({td_gc, Pid}, State) ->
    case is_process_alive(Pid) of
        true ->
            erlang:garbage_collect(Pid),
            erlang:exit(Pid, brutal_kill);
        _ -> ok
    end,
    {noreply, State};

handle_info(_Msg, State) ->
    {noreply, State}.

terminate(_Reason,  _State ) ->
    ok.

code_change(_OldVsn, State, _Extra) ->
    {ok, State}.
